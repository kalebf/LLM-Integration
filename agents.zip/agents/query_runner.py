import logging
from typing import List, Tuple, Optional, Any, Dict
from langchain_ollama import OllamaLLM
from sqlalchemy import text
from core.database import get_db
from core.config import settings

logger = logging.getLogger(__name__)

class QueryRunner:
    def __init__(self):
        self.llm = OllamaLLM(model=settings.LLM_MODEL)
    
    def execute_query(self, query: str, user_id: int) -> Dict[str, Any]:
        """Execute SQL query and return results"""
        db = next(get_db())
        try:
            # Wrap raw SQL with text()
            result = db.execute(text(query))
            
            if query.strip().upper().startswith('SELECT'):
                # Get column names and data for SELECT queries
                columns = list(result.keys())  # SQLAlchemy 2.0 way to get column names
                data = result.fetchall()
                return {
                    "columns": columns,
                    "data": data,
                    "rowcount": len(data)
                }
            else:
                # For non-SELECT queries, commit and return message
                db.commit()
                return {
                    "message": f"Query executed successfully. Rows affected: {result.rowcount}",
                    "rowcount": result.rowcount
                }
                
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise
        finally:
            db.close()
    
    def process_natural_language_query(self, user_query: str, user_id: int) -> str:
        """Process natural language query using LLM"""
        # Get database schema info
        schema_info = self._get_schema_info()
        
        prompt = f"""
        You are a SQL query generator for a personal finance application.
        
        Database Schema:
        {schema_info}
        
        Important Rules:
        1. Always filter by user_id = {user_id} to ensure data privacy
        2. Only generate SELECT queries (read-only)
        3. Use proper JOINs to connect related tables
        4. Return only the SQL query, no explanations
        
        User Question: {user_query}
        
        SQL Query:
        """
        
        try:
            sql_query = self.llm.invoke(prompt).strip()
            logger.info(f"Generated SQL: {sql_query}")
            
            # Execute the query
            result = self.execute_query(sql_query, user_id)
            
            # Format the result for response
            return self._format_query_result(result, user_query)
            
        except Exception as e:
            logger.error(f"Natural language query processing failed: {e}")
            return f"I encountered an error while processing your query: {str(e)}"
    
    def _get_schema_info(self) -> str:
        """Get database schema information for LLM context"""
        db = next(get_db())
        try:
            # Use text() wrapper for raw SQL
            query = text("""
            SELECT table_name, column_name, data_type 
            FROM information_schema.columns 
            WHERE table_schema = 'public'
            ORDER BY table_name, ordinal_position;
            """)
            
            result = db.execute(query)
            tables = {}
            
            for table_name, column_name, data_type in result.fetchall():
                if table_name not in tables:
                    tables[table_name] = []
                tables[table_name].append(f"{column_name} ({data_type})")
            
            schema_info = "\n".join([
                f"Table: {table}\nColumns: {', '.join(columns)}" 
                for table, columns in tables.items()
            ])
            
            return schema_info
            
        finally:
            db.close()
    
    def _format_query_result(self, result: Dict[str, Any], original_query: str) -> str:
        """Format query results into human-readable text"""
        if "message" in result:
            return result["message"]
        
        if not result.get("data"):
            return "No results found for your query."
        
        columns = result["columns"]
        data = result["data"]
        
        # Simple formatting
        response = f"Here are the results for '{original_query}':\n\n"
        
        # Show column headers
        response += " | ".join(columns) + "\n"
        response += "---" * len(columns) + "\n"
        
        # Show data rows (limit to 10 for readability)
        for i, row in enumerate(data[:10]):
            row_text = " | ".join([str(val) for val in row])
            response += f"{row_text}\n"
        
        if len(data) > 10:
            response += f"\n... and {len(data) - 10} more rows"
        
        return response