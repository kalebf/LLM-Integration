from typing import Dict, Any, Optional
from agents.query_runner import QueryRunner
from agents.visualizer import Visualizer
from core.database import get_db

class LLMAgent:
    def __init__(self):
        self.query_runner = QueryRunner()
        self.visualizer = Visualizer()
    
    def process_message(self, user_input: str, user_id: int) -> Dict[str, Any]:
        """
        Main entry point for processing user messages
        Returns structured response for the API
        """
        # Parse intent and parameters
        parsed_intent = self._parse_intent(user_input, user_id)
        
        # Check if we need clarification
        if self._needs_clarification(parsed_intent):
            return {
                "response": self._request_clarification(parsed_intent),
                "visualization_data": None,
                "needs_clarification": True
            }
        
        # Route to appropriate handler
        result = self._route_request(parsed_intent, user_id)
        
        return {
            "response": result.get("text_response", "I've processed your request."),
            "visualization_data": result.get("visualization"),
            "needs_clarification": False
        }
    
    def _parse_intent(self, user_input: str, user_id: int) -> Dict[str, Any]:
        """Parse user input to determine intent and extract parameters"""
        # Simple rule-based parsing - you can enhance this with LLM
        user_input_lower = user_input.lower()
        
        if any(word in user_input_lower for word in ['spend', 'expense', 'transaction']):
            return {
                "intent": "spending_analysis",
                "parameters": {"time_period": "current_month"},
                "needs_visualization": True
            }
        elif any(word in user_input_lower for word in ['budget', 'plan']):
            return {
                "intent": "budget_summary", 
                "parameters": {},
                "needs_visualization": True
            }
        else:
            return {
                "intent": "general_query",
                "parameters": {"query": user_input},
                "needs_visualization": False
            }
    
    def _needs_clarification(self, parsed_intent: Dict[str, Any]) -> bool:
        """Check if we need to ask for clarification"""
        # Implement logic to check for missing parameters
        return False
    
    def _request_clarification(self, parsed_intent: Dict[str, Any]) -> str:
        """Generate clarification question"""
        return "Could you please provide more specific details about your request?"
    
    def _route_request(self, parsed_intent: Dict[str, Any], user_id: int) -> Dict[str, Any]:
        """Route the request to appropriate handler"""
        intent = parsed_intent["intent"]
        
        if intent == "spending_analysis":
            return self._handle_spending_analysis(user_id, parsed_intent["parameters"])
        elif intent == "budget_summary":
            return self._handle_budget_summary(user_id)
        else:
            return self._handle_general_query(user_id, parsed_intent["parameters"])
    
    def _handle_spending_analysis(self, user_id: int, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Handle spending analysis requests"""
        # Use query_runner to get data
        query = f"""
        SELECT c.name as category, SUM(t.amount) as total_spent
        FROM transactions t
        JOIN categories c ON t.category_id = c.id
        WHERE t.user_id = {user_id}
        GROUP BY c.name
        ORDER BY total_spent DESC
        LIMIT 5
        """
        
        result = self.query_runner.execute_query(query, user_id)
        
        # Generate visualization
        visualization = self.visualizer.create_spending_chart(result)
        
        return {
            "text_response": f"Here's your spending analysis for the top categories.",
            "visualization": visualization
        }
    
    def _handle_budget_summary(self, user_id: int) -> Dict[str, Any]:
        """Handle budget summary requests"""
        query = f"""
        SELECT c.name, b.planned, COALESCE(SUM(t.amount), 0) as actual
        FROM budgetentries b
        JOIN categories c ON b.category_id = c.id
        LEFT JOIN transactions t ON t.category_id = c.id AND t.user_id = {user_id}
        WHERE b.budget_id IN (SELECT id FROM budgets WHERE user_id = {user_id})
        GROUP BY c.name, b.planned
        """
        
        result = self.query_runner.execute_query(query, user_id)
        visualization = self.visualizer.create_budget_vs_actual_chart(result)
        
        return {
            "text_response": "Here's your budget vs actual spending.",
            "visualization": visualization
        }
    
    def _handle_general_query(self, user_id: int, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Handle general queries using the SQL generator"""
        query_text = parameters["query"]
        result = self.query_runner.process_natural_language_query(query_text, user_id)
        
        return {
            "text_response": result,
            "visualization": None
        }