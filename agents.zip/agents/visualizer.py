import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from typing import Dict, Any, List, Tuple

class Visualizer:
    def create_spending_chart(self, query_result: Dict[str, Any]) -> Dict[str, Any]:
        """Create a spending chart from query results"""
        if not query_result.get("data"):
            return None
        
        df = pd.DataFrame(query_result["data"], columns=query_result["columns"])
        
        fig = px.bar(
            df, 
            x=df.columns[0], 
            y=df.columns[1],
            title="Spending by Category",
            labels={df.columns[0]: 'Category', df.columns[1]: 'Amount'}
        )
        
        return fig.to_dict()
    
    def create_budget_vs_actual_chart(self, query_result: Dict[str, Any]) -> Dict[str, Any]:
        """Create budget vs actual comparison chart"""
        if not query_result.get("data"):
            return None
        
        df = pd.DataFrame(query_result["data"], columns=query_result["columns"])
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            name='Planned Budget',
            x=df[df.columns[0]],
            y=df[df.columns[1]],
        ))
        
        fig.add_trace(go.Bar(
            name='Actual Spending',
            x=df[df.columns[0]],
            y=df[df.columns[2]],
        ))
        
        fig.update_layout(
            title="Budget vs Actual Spending",
            barmode='group'
        )
        
        return fig.to_dict()
    
    def create_trend_chart(self, query_result: Dict[str, Any]) -> Dict[str, Any]:
        """Create a trend line chart"""
        if not query_result.get("data"):
            return None
        
        df = pd.DataFrame(query_result["data"], columns=query_result["columns"])
        
        fig = px.line(
            df,
            x=df.columns[0],
            y=df.columns[1],
            title="Spending Trends Over Time"
        )
        
        return fig.to_dict()