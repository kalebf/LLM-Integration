from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+psycopg2://postgres:kalebf6201@localhost:5432/Test"
    LLM_MODEL: str = "llama3"
    #My Local:postgresql+psycopg2://postgres:kalebf6201@localhost:5432/Test
    #Actual: postgresql+psycopg2://clarifi_db_user:Fwe1upxTMYXo1xR8PMkoDaTGr8Xe35g3@dpg-d44kca8dl3ps73bdcn90-a.oregon-postgres.render.com:5432/clarifi_db
    class Config:
        env_file = ".env"

settings = Settings()