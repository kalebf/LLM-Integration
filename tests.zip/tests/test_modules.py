#!/usr/bin/env python3
"""
Test script to verify all imports work correctly.
"""
import sys
import os

# Add the parent directory to Python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

try:
    from agents.agent import Agent
    from agents.data_handler import DataHandler
    from agents.query_runner import QueryRunner
    from agents.intent_classifier import intent_classifier
    from agents.prompt_enhancer import PromptEnhancer
    from agents.updater import Updater
    
    print("All agent imports successful!")
    
    from core.config import settings
    from core.database import get_db
    print("All core imports successful!")
    
    from api.endpoints import router
    print("API imports successful!")
    
    print("\nAll imports working correctly!")
    
except ImportError as e:
    print(f"Import error: {e}")
except Exception as e:
    print(f"Other error: {e}")