import sys
import os

SOURCE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'clarifi_agent')

try:
    from core.database import SessionLocal
    from sqlalchemy import text
    
    def test_db_connection():
        try:
            db = SessionLocal()
            # Use text() wrapper for raw SQL
            result = db.execute(text("SELECT version()"))
            version = result.fetchone()
            print(f"Database connection successful!")
            if version is not None:
                print(f"Database version: {version[0]}")
            else:
                print("Could not retrieve database version.")
            db.close()
            return True
        except Exception as e:
            print(f"Database connection failed: {e}")
            return False

    if __name__ == "__main__":
        test_db_connection()

except ImportError as e:
    print(f"Import error: {e}")