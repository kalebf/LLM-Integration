from pydantic import BaseModel
from typing import Optional, Dict, Any, List

class ChatRequest(BaseModel):
    message: str
    user_id: int
    session_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    visualization_data: Optional[Dict[str, Any]] = None
    session_id: Optional[str] = None

class VisualizationRequest(BaseModel):
    user_id: int
    query_type: str
    parameters: Dict[str, Any]

class VisualizationResponse(BaseModel):
    plot_json: Dict[str, Any]
    summary: str