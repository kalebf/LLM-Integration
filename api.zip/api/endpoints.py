from fastapi import APIRouter, Depends, HTTPException
from typing import Dict, Any
from agents.llm_agent import LLMAgent
from models.schemas import ChatRequest, ChatResponse, VisualizationRequest, VisualizationResponse

router = APIRouter()
llm_agent = LLMAgent()

@router.post("/chat", response_model=ChatResponse)
async def process_chat_message(request: ChatRequest):
    """
    Process user chat message and return response with optional visualization
    """
    try:
        result = llm_agent.process_message(
            user_input=request.message,
            user_id=request.user_id
        )
        
        return ChatResponse(
            response=result["response"],
            visualization_data=result["visualization_data"],
            session_id=request.session_id
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/visualize", response_model=VisualizationResponse)
async def create_visualization(request: VisualizationRequest):
    """
    Create a visualization based on specific parameters
    """
    try:
        # This endpoint can be used for direct visualization requests
        # You can implement specific visualization logic here
        return VisualizationResponse(
            plot_json={},  # Your visualization data
            summary="Visualization created successfully"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "clarifi-agent"}